package com.example.admin.baithtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText txtresult;
    Button bt0,bt1,bt2,bt3,bt4,bt5,bt6,bt7,bt8,bt9,btc,btcong,bttru,btchia,btphantram,btnhan,btdel,btbang,btpoint;
    float a =0,b =0;
    boolean isxoa = false;

    private View.OnClickListener onclick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btphantram:btphantram_onClick();
                    break;
                case R.id.btbang: btbang_onClick();
                    break;
                case R.id.btc:btc_onClick();
                    break;
                case R.id.btchia: btchia_onClick();
                    break;
                case R.id.btcong: btcong_onClick();
                    break;
                case R.id.btdel: btdel_onClick();
                    break;
                case R.id.btnhan: btnhan_onClick();
                    break;
                case R.id.btpoint: btpoint_onClick();
                    break;
                case R.id.bttru: bttru_onClick();
                    break;
                case R.id.bt0: bt0_onClick();
                    break;
                case R.id.bt1: bt1_onClick();
                    break;
                case R.id.bt2: bt2_onClick();
                    break;
                case R.id.bt3: bt3_onClick();
                    break;
                case R.id.bt4: bt4_onClick();
                    break;
                case R.id.bt5: bt5_onClick();
                    break;
                case R.id.bt6: bt6_onClick();
                    break;
                case R.id.bt7: bt7_onClick();
                    break;
                case R.id.bt8: bt8_onClick();
                    break;
                case R.id.bt9: bt9_onClick();
                    break;
            }
        }
    };

    private void bt0_onClick() {
        if(isxoa) {
            txtresult.setText("0");
            isxoa = false;
        }

        else
        txtresult.setText(txtresult.getText()+"0");
    }

    private void bt1_onClick() {
        if(isxoa) {
            txtresult.setText("1");
            isxoa = false;
        }

        else
        txtresult.setText(txtresult.getText()+"1");
    }
    private void bt2_onClick() {
        if(isxoa) {
            txtresult.setText("2");
            isxoa = false;
        }

        else
        txtresult.setText(txtresult.getText()+"2");
    }
    private void bt3_onClick() {if(isxoa) {
        txtresult.setText("3");
        isxoa = false;
    }

    else
        txtresult.setText(txtresult.getText()+"3");
    }
    private void bt4_onClick() {if(isxoa) {
        txtresult.setText("4");
        isxoa = false;
    }

    else
        txtresult.setText(txtresult.getText()+"4");
    }
    private void bt5_onClick() {if(isxoa) {
        txtresult.setText("5");
        isxoa = false;
    }

    else
        txtresult.setText(txtresult.getText()+"5");
    }
    private void bt6_onClick() {if(isxoa) {
        txtresult.setText("6");
        isxoa = false;
    }

    else
        txtresult.setText(txtresult.getText()+"6");
    }
    private void bt7_onClick() {if(isxoa) {
        txtresult.setText("7");
        isxoa = false;
    }

    else
        txtresult.setText(txtresult.getText()+"7");
    }
    private void bt8_onClick() {if(isxoa) {
        txtresult.setText("8");
        isxoa = false;
    }

    else
        txtresult.setText(txtresult.getText()+"8");
    }
    private void bt9_onClick() {if(isxoa) {
        txtresult.setText("9");
        isxoa = false;
    }

    else
        txtresult.setText(txtresult.getText()+"9");
    }


    private void bttru_onClick() {
        a = Float.parseFloat(txtresult.getText().toString().trim());
        isxoa = true;
    }

    private void btpoint_onClick() {
        txtresult.setText(txtresult.getText()+".");
    }

    private void btnhan_onClick() {
        a = Float.parseFloat(txtresult.getText().toString().trim());
        isxoa = true;
    }

    private void btcong_onClick() {

        a = Float.parseFloat(txtresult.getText().toString().trim());
        isxoa = true;
    }

    private void btdel_onClick() {
    }

    private void btchia_onClick() {
        a = Float.parseFloat(txtresult.getText().toString().trim());
        isxoa = true;
    }

    private void btc_onClick() {
    }

    private void btbang_onClick() {
        b = Float.parseFloat(txtresult.getText().toString().trim());
        float sum = a+b;
        txtresult.setText(sum+"");
        isxoa = false;
        float tru = a-b;
        txtresult.setText(tru+"");
        float nhan = a*b;
        txtresult.setText(nhan+"");
        float chia = a/b;
        txtresult.setText(chia+"");

    }

    private void btphantram_onClick() {
        a = Float.parseFloat(txtresult.getText().toString().trim());
        b = 1/a;
        txtresult.setText(b+"");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt0 = findViewById(R.id.bt0);
        bt1 = findViewById(R.id.bt1);
        bt2 = findViewById(R.id.bt2);
        bt3 = findViewById(R.id.bt3);
        bt4 = findViewById(R.id.bt4);
        bt5 = findViewById(R.id.bt5);
        bt6 = findViewById(R.id.bt6);
        bt7 = findViewById(R.id.bt7);
        bt8 = findViewById(R.id.bt8);
        bt9 = findViewById(R.id.bt9);
        btcong = findViewById(R.id.btcong);
        bttru = findViewById(R.id.bttru);
        btphantram = findViewById(R.id.btphantram);
        btchia = findViewById(R.id.btchia);
        btdel = findViewById(R.id.btdel);
        btnhan = findViewById(R.id.btnhan);
        btc = findViewById(R.id.btc);
        btbang = findViewById(R.id.btbang);
        btpoint = findViewById(R.id.btpoint);
        txtresult = findViewById(R.id.txtresult);

        bt1.setOnClickListener(onclick);
        bt2.setOnClickListener(onclick);
        bt3.setOnClickListener(onclick);
        bt4.setOnClickListener(onclick);
        bt5.setOnClickListener(onclick);
        bt6.setOnClickListener(onclick);
        bt7.setOnClickListener(onclick);
        bt8.setOnClickListener(onclick);
        bt9.setOnClickListener(onclick);
        btcong.setOnClickListener(onclick);
        bttru.setOnClickListener(onclick);
        btphantram.setOnClickListener(onclick);
        btchia.setOnClickListener(onclick);
        btdel.setOnClickListener(onclick);
        btnhan.setOnClickListener(onclick);
        btc.setOnClickListener(onclick);
        btbang.setOnClickListener(onclick);
        btpoint.setOnClickListener(onclick);



    }
}
